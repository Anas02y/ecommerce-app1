'use client'
import React from 'react'
import { useCart } from './CartContext'
import Link from 'next/link'

export default function AddToCartButton({ product }: { product: any }) {
  const { add } = useCart()
  return (
    <>
      <button onClick={()=>add(product,1)} className="px-6 py-3 rounded-lg bg-primary text-white">Add to Cart</button>
      <Link href="/cart" className="px-4 py-3 rounded-lg glass">View Cart</Link>
    </>
  )
}
