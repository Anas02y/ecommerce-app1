'use client'
import React, { createContext, useContext, useEffect, useState } from 'react'

const ThemeContext = createContext<any>(null)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<'light'|'dark'>('light')

  useEffect(()=>{
    const t = localStorage.getItem('theme') as 'light'|'dark'|null
    if(t) setTheme(t)
  },[])

  useEffect(()=>{
    document.documentElement.classList.remove('dark')
    if(theme==='dark') document.documentElement.classList.add('dark')
    localStorage.setItem('theme', theme)
  },[theme])

  const toggle = ()=> setTheme(prev=> prev==='dark' ? 'light' : 'dark')

  return <ThemeContext.Provider value={{ theme, toggle }}>{children}</ThemeContext.Provider>
}

export const useTheme = ()=> {
  const ctx = useContext(ThemeContext)
  if(!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
