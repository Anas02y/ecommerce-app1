'use client'
import React from 'react'
import { useCart } from './CartContext'
import Link from 'next/link'

export default function CartToggle(){
  const { items } = useCart()
  return (
    <Link href="/cart" className="relative">
      <span>Cart</span>
      {items.length>0 && <span className="absolute -top-2 -right-3 bg-red-500 text-white text-xs rounded-full px-2">{items.length}</span>}
    </Link>
  )
}
