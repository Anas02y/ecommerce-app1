'use client'
import Link from 'next/link'
import React from 'react'
import { useTheme } from './ThemeToggle'
import CartToggle from './CartToggle'

export default function Navbar(){
  const { theme, toggle } = useTheme()
  return (
    <header className="w-full glass py-3 px-4 fixed top-4 left-0 right-0 z-40">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <Link href="/" className="text-lg font-bold flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary" />
          MyShop
        </Link>

        <nav className="flex items-center gap-4">
          <Link href="/admin" className="text-sm">Admin</Link>
          <Link href="/cart" className="text-sm">Cart</Link>
          <button onClick={toggle} className="px-3 py-2 rounded glass">{theme==='dark' ? 'Light' : 'Dark'}</button>
        </nav>
      </div>
    </header>
  )
}
