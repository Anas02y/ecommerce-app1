import Link from 'next/link'
import React from 'react'
import { formatPrice } from '../lib/formatPrice'

export default function ProductCard({ product }: { product: any }) {
  return (
    <article className="glass rounded-xl overflow-hidden shadow-sm card-hover">
      <Link href={`/product/${product.id}`}>
        <img src={product.images[0]} alt={product.name} className="w-full h-56 object-cover" />
        <div className="p-4">
          <h3 className="font-medium">{product.name}</h3>
          <div className="flex items-center justify-between mt-2">
            <div className="text-lg font-semibold">{formatPrice(product.price)}</div>
            <div className="text-sm text-gray-400">{product.rating} ★</div>
          </div>
        </div>
      </Link>
    </article>
  )
}
