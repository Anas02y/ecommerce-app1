'use client'
import React, { useEffect, useState } from 'react'
import products from '../data/products.json'

export default function AIRecommendations({ userId }: { userId?: string }) {
  const [recs, setRecs] = useState<any[]>([])

  useEffect(() => {
    // Placeholder: simple content-based recommendations (first 4 products)
    const p = products.slice(0, 4)
    setRecs(p)
  }, [])

  return (
    <section className="mt-8">
      <h3 className="text-lg font-semibold mb-3">Recommended for you</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {recs.map(r => (
          <div key={r.id} className="glass p-3 rounded">
            <img src={r.images[0]} className="w-full h-32 object-cover rounded" />
            <div className="mt-2 font-medium">{r.name}</div>
            <div className="text-sm text-gray-500">{new Intl.NumberFormat('en-US',{style:'currency',currency:r.currency}).format(r.price)}</div>
          </div>
        ))}
      </div>
    </section>
  )
}
