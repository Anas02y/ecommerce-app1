'use client'
import React, { createContext, useContext, useState } from 'react'

const CartContext = createContext<any>(null)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<any[]>([])

  const add = (product:any, qty=1) => {
    setItems(prev=>{
      const found = prev.find(p=>p.id===product.id)
      if(found) return prev.map(p=> p.id===product.id ? { ...p, quantity: p.quantity + qty } : p)
      return [...prev, { id: product.id, name: product.name, price: product.price, image: product.images[0], quantity: qty }]
    })
  }

  const remove = (id:string) => setItems(prev => prev.filter(p=>p.id!==id))
  const clear = () => setItems([])

  return <CartContext.Provider value={{ items, add, remove, clear }}>{children}</CartContext.Provider>
}

export const useCart = ()=> {
  const ctx = useContext(CartContext)
  if(!ctx) throw new Error('useCart must be used within CartProvider')
  return ctx
}
