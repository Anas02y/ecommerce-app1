import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const body = await req.json().catch(()=> ({}))
  await new Promise(r => setTimeout(r, 1000))
  return NextResponse.json({ ok: true, sessionId: 'sess_demo_12345', status: 'paid', data: body })
}
