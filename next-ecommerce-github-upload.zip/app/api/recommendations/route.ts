import products from '../../../data/products.json'
import { NextResponse } from 'next/server'

export async function GET(req: Request) {
  const recs = (products as any[]).slice(0,4)
  return NextResponse.json({ recommendations: recs })
}
