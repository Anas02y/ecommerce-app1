import products from '../../../data/products.json'
import { notFound } from 'next/navigation'
import { formatPrice } from '../../../lib/formatPrice'
import AddToCartButton from '../../../components/AddToCartButton'

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = (products as any[]).find(p => p.id === params.id)
  if (!product) return notFound()

  return (
    <section className="mt-10 grid md:grid-cols-2 gap-8">
      <div>
        <img src={product.images[0]} alt={product.name} className="w-full h-[480px] object-cover rounded-lg" />
      </div>
      <div>
        <h1 className="text-2xl font-bold">{product.name}</h1>
        <p className="text-xl mt-2">{formatPrice(product.price)}</p>
        <p className="mt-4 text-gray-500">{product.description}</p>

        <div className="mt-6 flex gap-3">
          <AddToCartButton product={product} />
          <button className="px-4 py-3 rounded-lg glass">Wishlist</button>
        </div>
      </div>
    </section>
  )
}
