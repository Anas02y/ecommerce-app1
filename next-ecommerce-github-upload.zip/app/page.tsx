import React, { useState } from 'react'
import products from '../data/products.json'
import ProductCard from '../components/ProductCard'
import SearchBar from '../components/SearchBar'
import AIRecommendations from '../components/AIRecommendations'

export default function HomePage() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const categories = ['All', ...Array.from(new Set(products.map(p=>p.category)))]
  const filtered = products.filter(p=> (category==='All' || p.category===category) && (p.name.toLowerCase().includes(query.toLowerCase()) || p.description.toLowerCase().includes(query.toLowerCase())))

  return (
    <section className="pt-6">
      <div className="flex items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Featured</h1>
          <p className="text-sm text-gray-500">Curated picks for you</p>
        </div>
        <div className="w-full max-w-md">
          <SearchBar value={query} onChange={setQuery} />
        </div>
      </div>

      <div className="mb-4 flex gap-3">
        {categories.map(cat=>(
          <button key={cat} onClick={()=>setCategory(cat)} className={cat===category ? 'px-4 py-2 rounded-full bg-primary text-white' : 'px-4 py-2 rounded-full glass'}>{cat}</button>
        ))}
      </div>

      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {filtered.map((p:any)=> <ProductCard key={p.id} product={p} />)}
      </div>

      <AIRecommendations />
    </section>
  )
}
