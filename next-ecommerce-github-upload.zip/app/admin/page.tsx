export default function AdminPage() {
  return (
    <section className="mt-10">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass p-6 rounded-lg">Products (demo data loaded from <code>/data/products.json</code>)</div>
        <div className="glass p-6 rounded-lg">Orders & analytics (placeholders)</div>
      </div>
    </section>
  )
}
