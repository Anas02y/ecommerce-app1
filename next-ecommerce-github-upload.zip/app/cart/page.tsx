'use client'
import React from 'react'
import { useCart } from '../../components/CartContext'
import Link from 'next/link'
import { formatPrice } from '../../lib/formatPrice'

export default function CartPage() {
  const { items, remove, clear } = useCart()
  const total = items.reduce((s:any,i:any)=> s + i.quantity * i.price, 0)

  return (
    <section className="mt-10">
      <h2 className="text-xl font-semibold">Your Cart</h2>
      <div className="mt-6 glass p-6 rounded-lg">
        {items.length===0 ? (
          <div>
            <p>Your cart is empty.</p>
            <Link href="/" className="text-primary">Continue shopping</Link>
          </div>
        ) : (
          <div>
            <ul className="space-y-4">
              {items.map((it:any)=>(
                <li key={it.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img src={it.image} className="w-16 h-16 object-cover rounded" />
                    <div>
                      <div className="font-medium">{it.name}</div>
                      <div className="text-sm text-gray-500">{formatPrice(it.price)}</div>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm">Qty: {it.quantity}</div>
                    <button onClick={()=>remove(it.id)} className="text-sm text-red-500 mt-2">Remove</button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <div>
                <button onClick={()=>clear()} className="px-4 py-2 glass rounded">Clear Cart</button>
              </div>
              <div>
                <div className="text-lg font-semibold">{formatPrice(total)}</div>
                <Link href="/checkout" className="ml-4 px-4 py-2 bg-primary text-white rounded">Checkout</Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
