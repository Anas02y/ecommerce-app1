import './styles/globals.css'
import React from 'react'
import Navbar from '../components/Navbar'
import { CartProvider } from '../components/CartContext'
import { ThemeProvider } from '../components/ThemeToggle'

export const metadata = { title: 'MyShop - Premium Store', description: 'Premium minimal e-commerce demo' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <ThemeProvider>
          <CartProvider>
            <Navbar />
            <main className="max-w-6xl mx-auto p-4 mt-20">{children}</main>
          </CartProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
