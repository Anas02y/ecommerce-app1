'use client'
import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '../../components/CartContext'
import { formatPrice } from '../../lib/formatPrice'

export default function CheckoutPage() {
  const { items, clear } = useCart()
  const router = useRouter()
  const total = items.reduce((s:any,i:any)=> s + i.quantity * i.price, 0)
  const [processing, setProcessing] = useState(false)

  const pay = async () => {
    setProcessing(true)
    // call demo API
    await fetch('/api/checkout', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({amount: total}) })
    await new Promise(r=>setTimeout(r, 500))
    clear()
    router.push('/checkout/success')
  }

  if (items.length===0) return <div className="mt-10">Your cart is empty.</div>

  return (
    <section className="mt-10">
      <h2 className="text-xl font-semibold">Checkout</h2>
      <div className="mt-6 glass p-6 rounded-lg">
        <div className="mb-4">Total: <strong>{formatPrice(total)}</strong></div>
        <button onClick={pay} disabled={processing} className="px-4 py-2 bg-primary text-white rounded">
          {processing ? 'Processing...' : 'Pay (Demo)'}
        </button>
      </div>
    </section>
  )
}
