import React from 'react'
import Link from 'next/link'

export default function SuccessPage() {
  return (
    <section className="mt-10">
      <div className="glass p-8 rounded-lg text-center">
        <h1 className="text-2xl font-bold">Payment Successful</h1>
        <p className="mt-4">Thank you for your purchase. Your order is being prepared.</p>
        <Link href="/" className="mt-6 inline-block bg-primary text-white px-4 py-2 rounded">Continue Shopping</Link>
      </div>
    </section>
  )
}
